
export default function PrivacyPolicy() {
  return (
    <div className="prose prose-invert">
      <h1>Privacy Policy</h1>
      <p>We only collect data needed to process orders. Card data is never stored.</p>
    </div>
  );
}
